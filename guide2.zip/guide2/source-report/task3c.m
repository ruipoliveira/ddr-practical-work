br0 = 1; 
br1 = 5;
br2 = 5; 
br3 = 10;

ded1 = 100; 
ded2 = 50; 
ded3 = 50; 
ded4 = 20; 

duration0 = (1/br0)*60
duration1 = (1/(br1+ded1))*60
duration2 = (1/(br2+ded2))*60
duration3 = (1/(br3+ded3))*60
duration4 = (1/ded4)*60